import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CommonModule } from '@angular/common'; 
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { CharacterDetailDialogComponent } from '../character-detail-dialog/character-detail-dialog.component';
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-character-list',
  templateUrl: './character-list.component.html',
  styleUrls: ['./character-list.component.css'],
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatPaginatorModule] 
})
export class CharacterListComponent implements OnInit {
  characters: any[] = [];
  totalCharacters: number = 0;
  pageSize: number = 20;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private http: HttpClient, public dialog: MatDialog, private router: Router) {}

  ngOnInit() {
    const token = localStorage.getItem('token');
    if (!token) {
      this.router.navigate(['/login']); 
    } else {
      this.fetchCharacters(0);
    }
  }

  fetchCharacters(offset: number) {
    const url = `http://localhost:8080/api/characters?limit=${this.pageSize}&offset=${offset}`;
    const token = localStorage.getItem('token'); 
    if (token) {
      const headers = new HttpHeaders({
        'Authorization': `Bearer ${token}`
      });

      this.http.get<any>(url, { headers })
        .subscribe(response => {
          this.characters = response.data.results;
          this.totalCharacters = response.data.total;
        });
    }
  }

  onPageChange(event: any) {
    const offset = event.pageIndex * this.pageSize;
    this.fetchCharacters(offset);
  }

  openCharacterDetail(characterId: number): void {
    const token = localStorage.getItem('token'); 

    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+token || ''
    });

    this.http.get<any>(`http://localhost:8080/api/characters/${characterId}`, { headers })
      .subscribe(response => {
        this.dialog.open(CharacterDetailDialogComponent, {
          width: '600px',
          data: response.data.results[0]
        });
      });
  }
}
