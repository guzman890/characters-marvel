import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service'; 
import { Subscription } from 'rxjs';
import { RegisterComponent } from '../register/register.component';
import { CommonModule } from '@angular/common';
import { CharacterListComponent } from '../character-list/character-list.component';
import { RequestLogsComponent } from '../request-logs/request-logs.component';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css'],
  standalone: true,
  imports: [CommonModule, RegisterComponent, CharacterListComponent, RequestLogsComponent] 
})
export class NavBarComponent implements OnInit, OnDestroy  {
  username: string = '';
  password: string = '';
  isLoggedIn: boolean = false;
  showCharacterList: boolean = true;

  private usernameSubscription: Subscription = new Subscription();

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    
    this.username = this.authService.getUsername();
    this.usernameSubscription = this.authService.username$.subscribe(
      username => this.username = username || ''    );
    
    const username = localStorage.getItem('username');
    if (username) {
      this.username = username
    }
  }

  toggleView(view: string) {
    this.showCharacterList = view === 'characters';
    if (view === 'characters') {
      this.router.navigate(['/characters']);
    } else if (view === 'logs') {
      this.router.navigate(['/logs']);
    }
  }

  logout(): void {
    this.isLoggedIn = false;
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  ngOnDestroy(): void {
    if (this.usernameSubscription) {
      this.usernameSubscription.unsubscribe();
    }
  }
}