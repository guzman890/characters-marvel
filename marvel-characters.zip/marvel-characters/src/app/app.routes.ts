import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { CharacterListComponent } from './character-list/character-list.component';
import { RequestLogsComponent } from './request-logs/request-logs.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'logs', component: RequestLogsComponent },
  { path: 'characters', component: CharacterListComponent },
  { path: '**', redirectTo: '/login' }
];