import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router'; 

@Component({
  selector: 'app-request-logs',
  templateUrl: './request-logs.component.html',
  styleUrls: ['./request-logs.component.css'],
  standalone: true,
  imports: [CommonModule]
})
export class RequestLogsComponent implements OnInit {
  requestLogs: any[] = [];

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    const token = localStorage.getItem('token');
    if (!token) {
      this.router.navigate(['/login']); 
    } else {
      this.fetchRequestLogs();
    }
  }

  fetchRequestLogs() {
    const url = 'http://localhost:8080/api/request-logs';
    this.http.get<any[]>(url).subscribe(
      response => {
        this.requestLogs = response;
      },
      error => {
        console.error('Error fetching request logs:', error);
      }
    );
  }
}