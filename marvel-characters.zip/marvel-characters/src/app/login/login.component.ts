import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms'; 

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [FormsModule] 
})

export class LoginComponent implements OnInit{
  
  credentials = { username: '', password: '' };

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit() {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
  }

  onSubmit() {
    this.authService.login(this.credentials).subscribe(
      response => {
        if (response.jwt) {
          this.router.navigate(['/characters']);
        }
      },
      error => {
        console.error('Login failed', error);
      }
    );
  }
}