import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';   


@Injectable({
  providedIn: 'root'
})
export class AuthService implements OnInit {
  private registerUrl = 'http://localhost:8080/register';
  private apiUrl = 'http://localhost:8080/authenticate'; 
  private usernameSubject = new BehaviorSubject<string | null>(null);
  isLoggedIn = false; 
  username$ = this.usernameSubject.asObservable();

  ngOnInit() {

  }

  constructor(private http: HttpClient) { }

  isLogged() {
    const token = localStorage.getItem('token');
    if (token) {
      this.isLoggedIn = true;
    }
    return this.isLoggedIn;
  }

  getUsername() {
    const username = localStorage.getItem('username');
    if (username) {
      return username;
    }
    return "Usuario not logged";
  }

  login(credentials: any): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(this.apiUrl, credentials, { headers })
      .pipe(
        tap((response: any) => {
          if (response.jwt) {
            this.isLoggedIn = true;
            localStorage.setItem('token', response.jwt);
            localStorage.setItem('username', credentials.username);
            this.usernameSubject.next(credentials.username);
          }
        })
      );
  }

  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    this.usernameSubject.next(null);
  }

  getIsLoggedIn() {
    return this.isLoggedIn;
  }

  register(username: string, password: string): Observable<any> {
    const body = { username, password };
    return this.http.post<any>(this.registerUrl, body, {
      headers: { 'Content-Type': 'application/json' }
    });
  }
}